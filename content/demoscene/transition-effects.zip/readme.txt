Transition effects / hannu

16 byte DOS intro for a slow 386
presented at Lovebyte 2023

There's a 17-byte 286/VGA compatible version in transition-effects-286.asm /
_tfx286.com. It doesn't use the IMUL r16,r16 instruction that was introduced in
386. This version should run on the first computer I had access to as a child
in around 1989, a 286. <3

Recommended platforms:
- DOSBox-X or DOSBox Staging running at 750 cycles
- a slow 386 (12MHz with "turbo" off)
- 86Box with 80286 and VGA for the 17-byte 286 version

Greets to all sizecoders!

https://hannuhartikainen.fi/demoscene
