                net growth
                 by hannu

          16 byte intro for DOS
            for Lovebyte Turbo 
               @ Evoke 2022

                   ***

      Back when I saw *ruler 16b* by
 byteobserver at Lovebyte 2022 I knew I'd
 have to dissect it and see what I could
           come up with myself.

 Hearing about Lovebyte Turbo gave me the
         reason to do just that.

 Thanks to byteobserver for inspiration!

                   ***

        Greets to all sizecoders!

  https://hannuhartikainen.fi/demoscene/
