RAINBOW FLASH / hannu
8 byte intro for 8088 (or 86Box or Dosbox-X)
Lovebyte 2024

To run on Dosbox-X, try

  dosbox-x -set cputype=8086_prefetch -set machine=cga \
           -set vmemsizekb=64 -set cycles=240 -fastlaunch \
           rbwflash.com

Compo video recorded on 86Box emulating IBM XT with a FreeDOS bootdisk. It
should be more accurate than any of the dosboxes, but it's not very fun to work
with.

The source file contains a writeup.

Greets to all sizecoders!
