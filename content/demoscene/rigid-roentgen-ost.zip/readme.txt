Rigid Roentgen OST / hannu
executable music for Linux
Lovebyte 2024

About 10 hours after the original submission deadline I remembered one
of my first sizecoded things, a bytebeat for Linux I made in 2021. It
later became the soundtrack for RIGID ROENTGEN 256B (DOS, 2022), though
with 16-bit registers it wasn't as good as the original.

The ELF32 binary is 77 bytes including a 45-byte header (with 10 bytes of code
embedded in header). You need to start it by running one of

  ./rigid-roentgen|aplay
  ./rigid-roentgen>/dev/dsp

So I guess that's 6-9 extra bytes on the command line. Or perhaps a shell
script of about 30 bytes.

Greets to all sizecoders and Linux hackers!
