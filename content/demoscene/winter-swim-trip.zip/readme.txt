 Winter Swim Trip / hannu
 C64, 256 bytes
 Lovebyte 2024

 SYS 4096 to start.

A big shout out to Pestis whose seminar on procedural music inspired this.
The music came first, then I had to learn to do textmode graphics on C64. I
had some custom font code but then synchronizing simple patterns to the beat
felt cooler than focusing on visuals. This is about the music.

It's also my first larger prod for C64, hope you like it!

Greets to all sizecoders!
