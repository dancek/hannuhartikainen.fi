fuzzy or black and white? / hannu
16B DOS intro for Lovebyte 2024

Chaos or order? Randomness or structure? Noise or patterns?
The elusive balance of ambiguity always leaves you contemplating.
Just as you have the answer within grasp, your perception changes.
It's difficult to see like your past self did – yet your current
view is already about to dissolve.

Intended to run at 8086 speeds, eg. a 386 with turbo button OFF.
Or more practically, `dosbox-x -set cycles=300 fuzzybw.com`

Greets to all sizecoders!
