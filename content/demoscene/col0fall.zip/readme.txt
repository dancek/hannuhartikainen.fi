col0fall (C64) / hannu

colorful pseudo-waterfall in 0x0f bytes
presented at Lovebyte 2023

greets to all sizecoders!

https://hannuhartikainen.fi/demoscene
