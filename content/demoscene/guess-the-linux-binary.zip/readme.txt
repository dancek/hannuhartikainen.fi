guess-the-linux-binary / hannu
nanogame (256B) for Linux
Lovebyte 2024

Guess the name of a Linux executable. Get one point for each correct
guess. The game ends after three incorrect guesses.

The game is implemented as a POSIX shell script that makes minimal
assumptions about the system. It's also sizecoded and breaks most best
practices related to shell scripting.

The game should run on almost any POSIX system. At least any Linux. The
only non-POSIX assumption I know of is that the `shuf` utility is
available; it's part of GNU coreutils but an implementation is also
shipped in Busybox and FreeBSD among others. If your system doesn't have
it, replace with `sort -R` and the game works!

If your system symlinks /bin -> /usr/bin, the game may be ridiculously
hard as you need to guess `lsp-plugins-sc-mb-compressor-mono` and such.
You can still get a fun game by running in a container:

    # easy: Alpine Linux (Busybox)
    docker run -it -v "$(pwd)":/x alpine /x/guess-the-linux-binary
    # intermediate: Ubuntu
    docker run -it -v "$(pwd)":/x ubuntu /x/guess-the-linux-binary

Have fun while enhancing your sysadmin-fu!

Greets to all sizecoders!
