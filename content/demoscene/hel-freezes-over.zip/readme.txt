HEL freezes over / hannu
256b TIC-80 intro for Lovebyte 2024

There was a blizzard in Southern Finland and I was
looking out of the window in a train. Buildings
passing by, changing wind and repeating whiteouts
were a bleak yet overwhelmingly beautiful sight.
The power of nature. It's almost a yearly occasion
yet every time you wonder how anyone could live here
without indoor spaces, heating and a food supply chain.

Looking at the view, I thought an intro could capture
a glimpse of the beauty. I tried my best to make the
snowflakes dance realistically -- everything else was
sizecoded.

Greets to all sizecoders!
