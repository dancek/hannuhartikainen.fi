Synthwave camouflage / hannu

8 byte intro for 8088
presented at Lovebyte 2023

This intro runs STOSW while incrementing DI by varying amounts. That eventually
causes STOSW to be run with DI=FFFF which causes a General Protection Fault.
But General Protection Faults were introduced in 80286 so on x86's before that,
namely 8088, this should work. At least 86Box, the emulator, emulates a GPF on
286 yet the program works on 8088.

Dosboxes (except DOSBox-X) are fine with the code. Just set cycles to 300 and
enjoy the intro. The effect does look better with muddy low-contrast CRT
emulation, though.

For running with 86Box or 8088 hardware I recommend PC-DOS 2.10. PC-DOS 1.x
doesn't work due to reliance on SI=0x0100. FreeDOS works too, and for IBM XT
and better MS-DOS 3.30 is an option.


Greets to all sizecoders!

https://hannuhartikainen.fi/demoscene
