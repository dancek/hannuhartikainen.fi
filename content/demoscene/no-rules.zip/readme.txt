No Rules! / hannu
executable graphics (256b, TIC-80)
Lovebyte 2024

This readme contains spoilers.

The executable graphics compo is scheduled to be on 2024-02-10 at 17
UTC+1. One of the biggest media events of the year in Finland is held on
the same day at 21 UTC+2. Ie. three hours later. That event is Uuden
Musiikin Kilpailu, a music competition where the winner gets to
represent Finland in Eurovision.

This got me thinking. My favorite contestant this year is one whom I
first saw live in 2017 and have liked a lot ever since. Windows95man. I
believe his aesthetics may also appeal to some of the sceners watching
Lovebyte, so why not advertise the artist in a prod. Not sure if it's a
good idea, but the song's name says it: No Rules!

After some trial and error I had a convincing Windows 95 logo lookalike
in some 600 bytes. I knew TIC-80 code compresses rather well so at this
point I started coming up with grand ideas of how I want the logo to
build up, then write a couple of lines of text one character at a time.
I also thought of adding clouds in the background. And I tried
compressing the thing, and it was like 280 bytes. But hey, everyone is a
newbie at first! :D

Still I loved the idea of drawing bits and pieces such that it takes
time to recognize the logo, and then adding text that changes the
meaning. So I did all I could to reduce code and make it compress
better, including uglifying the logo, positioning stuff in less pleasing
positions, changing the text timing to earlier than I like and whatnot.
In the end I made it as is always the case when you read stories like
this in a readme. Thanks for reading btw!


Greets to
 - you, for being interested in this readme
 - pestis, for pakettic and the procedural music seminar
 - everyone who contributes to the scene, for making newcomers welcome
 - Windows95man, for being so cool
 - all sizecoders, as always!
