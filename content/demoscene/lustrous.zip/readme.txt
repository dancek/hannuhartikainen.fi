lustrous / hannu

63 byte DOS intro
presented at Lovebyte 2023


Last year I had just learned about sizecoding and had the ambitious target
of submitting something to all highend size categories. I found 256 bytes
hard (who can write that much content!) but in the end 64 bytes turned out
to be my arch nemesis. Very difficult to come up with anything worthwhile
that isn't either 35 or 70 bytes. Finally I did find the idea for HYPERBOLAE
64B, did a lot of debugging and tweaking to make it work on hardware and fit in
64 bytes, and was left feeling this size category is not for me.

This year I just looked at my previous FPU productions looking for ideas. It
only took ten minutes of fiddling with the hyperbolae codebase and I had two
different ideas I liked. So the codebase is mostly the same.

The intro was developed on DOSBox Staging. I checked that it works on
FreeDOS+QEMU but it's too fast, and on DOSBox-X it's too slow. Probably
suitable for an early Pentium or something. Emulators are slow with FPUs,
DOSBox Staging being the most reasonable.

Some people dislike the MCGA palette. I think it's excellent here.


Greets to all sizecoders!

https://hannuhartikainen.fi/demoscene
