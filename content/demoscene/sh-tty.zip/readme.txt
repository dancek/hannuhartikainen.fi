sh!tty / hannu
32 byte intro for Linux
Lovebyte 2024

Nobody writes 32 byte intros for Linux, and for a very good reason. An
ELF32 header is 45 bytes at a minimum (though you can slip a couple of
bytes of code in there). Also there's no portable way of doing graphics
– and even the unportable ones require a lot of bytes for setup.

But Linux executables are not just binaries. Shell scripts exist too!

This prod consists of 10 bytes of compulsory header (#!/bin/sh\n) and 30
bytes of code. It should work on almost any POSIX system (and throw
errors every now and then – great for variety!).

Even without the header exclusion rule that Lovebyte has, *something* is
possible in under 64 bytes. And with the header not counted, there's
almost as much freedom in 32 bytes of shell script as there's in 8 bytes
of binary for DOS!

Greets to all sizecoders!
